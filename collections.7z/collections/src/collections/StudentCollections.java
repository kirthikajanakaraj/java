package collections;

import java.util.*;
import java.util.ArrayList;
import java.util.Collections;

class Student implements Comparable<Student> {
	private int roll;
	private String name, address;

	public int getRoll() {
		return roll;
	}

	public void setRoll(int roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Student(int roll, String name, String address) {
		this.roll = roll;
		this.name = name;
		this.address = address;
	}

	public String toString() {
		return this.roll + " " + this.name + " " + this.address;
	}

	/*
	 * @Override public int compareTo(Student o) { // TODO Auto-generated method
	 * stub return this.roll==o.roll; }
	 */
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		return 0;
	}
}

/*
 * class Sortbyroll implements Comparator<Student> { public int compare(Student
 * a,Student b) { return a.roll-b.roll; } }
 */

public class StudentCollections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		ArrayList<Student> sc = new ArrayList<Student>();
		sc.add(new Student(111, "anjali", "bangalore"));
		sc.add(new Student(121, "anuoop", "salem"));
		sc.add(new Student(131, "deepu", "chennai"));
		sc.add(new Student(141, "vivek", "mysore"));
		/*
		 * System.out.println("UNSORTED"); //for(String s:sc) for(int
		 * i=0;i<sc.size();i++) { System.out.println(sc.get(i)); }
		 * Collections.sort(sc); System.out.println("SORTED"); //for(String
		 * s1:sc) for(int i=0;i<sc.size();i++) { System.out.println(sc.get(i));
		 * }
		 */
		System.out.println("Enter your choice:");
		int choice = s.nextInt();
		Student s1 = null;
		for (int i = 0; i < sc.size(); i++) {
			s1 = sc.get(i);
			if (s1.getRoll() == choice) {
				System.out.println(s1);
			}
		}
		// System.out.println("display all");

		/*
		 * switch(choice) { case 111: System.out.println(sc.get(0)); break; case
		 * 121: System.out.println(sc.get(1)); break; case 131:
		 * System.out.println(sc.get(2)); break; case 141:
		 * System.out.println(sc.get(3)); break; default:
		 * System.out.println("Invalid Input");
		 * 
		 * }
		 */

	}
}
