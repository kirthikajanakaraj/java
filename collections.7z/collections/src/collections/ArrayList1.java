package collections;
import java.util.*;
public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=6;
		ArrayList<Integer> al=new ArrayList();
		for(int i=1;i<10;i++)
		{
			al.add(i);
		}
		System.out.println("ARRAYLIST--->"+al);
		al.remove(3);
		System.out.println("REMOVELIST-->"+al);
		for(int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i)+"");
		}
		}

}
