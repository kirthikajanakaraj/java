package collections;
import java.util.*;

public class HashCode1 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		StudentHash11 s=new StudentHash11(1,"kirthi");
		StudentHash11 s1=new StudentHash11(1,"kirthi");
		StudentHash11 s2=new StudentHash11(2,"prahi");
		StudentHash11 s3=new StudentHash11(3,"heman");
		System.out.println("Student=="+s.hashCode());
		System.out.println("Student1=="+s1.hashCode());
		System.out.println("Checking=="+s.equals(s1));
		List<StudentHash11>st=new ArrayList();
		st.add(s);
		st.add(s1);
		st.add(s2);
		st.add(s3);
	}	
}

class StudentHash11 
{
	private int id;
	private String name;
	public StudentHash11(int id,String name)
	{
		this.name=name;
		this.id=id;
	}
	@Override
	public String toString() 
	{
		return "StudentHash11 [id=" + id + ", name=" + name + "]";
	}
	@Override
	public int hashCode() 
	{
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj)
	{
		if(this == obj) 
		{
			return true;
		}
	
		StudentHash11 m=(StudentHash11) obj	;
		return id==m.id; 
	}
	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	
}
