package collections;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Set1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String>s=new HashSet<String>();
		s.add("pandi");
		s.add("donkey");
		s.add("monkey");
		s.add("horse");
		s.add("pig");
		System.out.println("HASHSET-->"+s);
		Set<String>t=new TreeSet<String>(s);
		System.out.println("TREESET-->"+t);
		
		
	}

}
