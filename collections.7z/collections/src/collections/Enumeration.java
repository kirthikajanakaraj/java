package collections;

import java.util.*;


public class Enumeration {
	public static void main(String args[])
	{
		Vector<Integer> v=new Vector<Integer>();
		for(int i=0;i<10;i++)
		{
			v.addElement(i);
		}
		System.out.println("VECTOR LIST---->"+v);
		Enumeration e=(Enumeration) v.elements();
		while(((java.util.Enumeration) e).hasMoreElements())
		{
			int i=(Integer)((java.util.Enumeration) e).nextElement();
			System.out.println(i+"");
		}
	}

	public boolean hasMoreElements() {
		// TODO Auto-generated method stub
		return false;
	}

	
	}


