package collections;

public class Student1 {

}
