package collections;

import java.util.*;

public class Enumeration1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v=new Vector();
		for(int i=0;i<10;i++)
		{
			v.addElement(i);
		}
		System.out.println("Vector---->"+v);
		Enumeration e=(Enumeration) v.elements();
		while(e.hasMoreElements())
		{
			int i=(Integer)e.nextElement();
			System.out.println("LIST--->"+i);
		}
		
	}

}
