package collections;

import java.util.Arrays;
import java.util.List;

public class Wildcard {
	public static void main(String args[])
	{
		List<Integer>list1=Arrays.asList(8,9,10,4,56,89);
		System.out.println("SUM TOTAL-->"+sum(list1));
		List<Double>list2=Arrays.asList(5.2,6.8,9.2,1.7,3.8);
		System.out.print("SUM TOTAL-->"+sum(list2));
		//printlist(list1);
		//printlist(list2);
	}
//	private static void printlist(List<Integer> list1) {
//		// TODO Auto-generated method stub
//		System.out.println(list);
	//}
private static void sum(List<? extends Number> list)
{
		double sum=0.0;
		for(Number i:list)
		{
			sum+=i.doubleValue();
		}
	}
}

