package collections;

import java.util.ArrayList;
import java.util.Collections;

public class ListSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al=new ArrayList<String>();
		al.add("superman");
		al.add("hemen");
		al.add("ironman");
		al.add("batman");
		al.add("spiderman");
		Collections.sort(al);
		System.out.println("LIST AFTER SORT"+al);
		Collections.sort(al,Collections.reverseOrder());
		System.out.println("LIST REVERSE"+al);
	}

}
