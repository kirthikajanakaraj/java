package collections;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
public class IteratorList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListIterator<String>li=null;
		List<String>n=new ArrayList<String>();
		n.add("table");
		n.add("chair");
		n.add("CPU");
		n.add("monitor");
		li=n.listIterator();
		System.out.println("-----------------FORWARD-------------------------------------");
		//while(li.hasNext())
		//{
		//System.out.print(li.next()+" ");
	//}
		li.add("mamammamammamam");
			for(int i=0;i<n.size();i++){
				
		System.out.print(n.get(i)+" ");	
			
		}
		/*System.out.println();
		System.out.println("---------------------BACKWARD-------------------");
		//n.add("keyborad");
		while(li.hasPrevious())
		{
			System.out.print(li.previous()+" ");
		}*/
	}

}
