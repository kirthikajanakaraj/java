package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class iteratorlist2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al=new ArrayList();
		for(int i=0;i<10;i++)
		{
			al.add(i);
		}
		System.out.println("ARRAYLIST---->"+al);
		ListIterator i=al.listIterator();
		while(i.hasNext())
		{
			int sum=(int) i.next();
		
		System.out.println(sum);
		
		if(sum%2==0)
		{
			sum++;
			i.set(sum);
			i.add(sum);
			
		}
		}
		System.out.println();
		System.out.println(al);
	}

	}


