package collections;

public class StudentHash {
	private int id;
	private String name;
	public StudentHash(int id,String name)
	{
		this.name=name;
		this.id=id;
	}
	void setId(int id)
	{
		this.id=id;
	}
	void setName(String name)
	{
		this.name=name;
	}
	int getId()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
}
