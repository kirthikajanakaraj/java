package collections;

import java.util.ArrayList;

public class Iterator2 {
	public static void main(String args[])
	{
		ArrayList<String>b=new ArrayList<String>();
		b.add("C");
		b.add("JAVA");
		b.add("C++");
		b.add("COBOL");
		for(String s:b)
		{
			System.out.println(s);
			//b.add("PHYTON");
		}
	}

}
