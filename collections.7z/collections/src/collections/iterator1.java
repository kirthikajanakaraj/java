package collections;

import java.util.ArrayList;
import java.util.Iterator;

public class iterator1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al=new ArrayList();
		for(int i=0;i<10;i++)
		{
			al.add(i);
		}
		System.out.println("ARRAYLIST---->"+al);
		Iterator i=al.iterator();
		while(i.hasNext())
		{
			int sum=(int) i.next();
		
		System.out.println(sum);
		
		if(sum%2==0)
		{
			i.remove();
		}
		}
		System.out.println();
		System.out.println(al);
	}

}
