package collections;

import java.util.LinkedList;

public class LinkedList1
{
	public static void main(String args[])
	{
		LinkedList<String>li=new LinkedList<String>();
		li.add("Apple");
		li.add("Orange");
		li.add("kiwi");
		li.add("litchee");
		System.out.println("LIST-->"+li);
		li.remove("kiwi");
		System.out.println("LIST-->"+li);
		boolean status=li.contains("Orange");
		if(status)
		{
			System.out.println("List contains all elements");
		}
		else
		{
			System.out.println("List doesn't contain elements");
		}
		int size=li.size();
		System.out.println("Size of list--->"+size);
		//Object e=object.get(2);
		
	}	
	
}
