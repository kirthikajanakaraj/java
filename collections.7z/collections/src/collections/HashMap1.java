package collections;

import java.util.*;

public class HashMap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Integer>hm=new HashMap<String,Integer>();
		hm.put("A",new Integer(100));
		hm.put("B",new Integer(200));
		hm.put("C",new Integer(300));
		hm.put("D",new Integer(400));
		Set<Map.Entry<String,Integer>>st=hm.entrySet();
		for(Map.Entry<String,Integer>m:st)
		{
			System.out.println(m.getKey()+":");
			System.out.println(m.getValue());
		}
	}

}
