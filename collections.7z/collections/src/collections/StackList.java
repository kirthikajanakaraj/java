package collections;

import java.util.Stack;

public class StackList {
	
	static void stack_push(Stack<Integer>s)
	{
		for(int i=0;i<5;i++)
		{
			s.push(i);
		}
	}
	static void stack_pop(Stack<Integer>s)
	{
		System.out.println("POP ELEMENT");
		for(int i=0;i<5;i++)
		{
			Integer y=s.pop();
			System.out.println(y);
		}
	}
	static void stack_peek(Stack<Integer>s)
	{
		Integer e=s.peek();
		System.out.println("ELEMENT IN TOP"+e);
	}
	static void search(Stack<Integer>s,int e)
	{
		Integer p=s.search(e);
		if(p==-1)
		{
			System.out.println("Element not found");
		}
		else
		{
			System.out.println("Element is found"+p);
		}
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Stack<Integer>s=new Stack<Integer>();
		stack_push(s);
		stack_pop(s);
		stack_peek(s);
		search(s,2);
		search(s,4);
		
	}

}
