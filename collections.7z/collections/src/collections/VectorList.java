package collections;
import java.util.Vector;
public class VectorList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> v=new Vector<String>(2);
		v.addElement("raspberry");
		v.addElement("blueberry");
		v.addElement("blackberry");
		v.addElement("redberry");
		v.addElement("gooseberry");
		System.out.println("SIZE OF----->"+v.size());
		System.out.println("CAPACITY---->"+v.capacity());
		v.addElement("mangoberry");
		v.addElement("strawberry");
		v.addElement("pineberry");
		System.out.println("SIZE OF----->"+v.size());
		System.out.println("CAPACITY---->"+v.capacity());
		//Enumeration e=v.elements();
		
		
		
	}

}
