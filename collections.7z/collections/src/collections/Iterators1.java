package collections;

import java.util.Iterator;
import java.util.ArrayList;
public class Iterators1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
               ArrayList<String> n=new ArrayList<String>();
               n.add("pulse");
               n.add("heart");
               n.add("nerves");
               n.add("blood");
               //n.add("567");
               Iterator it=n.iterator();
               while(it.hasNext())
               {
            	   String s=(String)it.next();
            	   System.out.println(s);
            	   //n.add("bone");
               }
               
	}

}
