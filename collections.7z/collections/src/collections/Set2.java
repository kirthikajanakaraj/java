package collections;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Set2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer>s=new HashSet<Integer>();
		s.addAll(Arrays.asList(new Integer[]{1,2,3,4,5,6}));
		Set<Integer>s1=new HashSet<Integer>();
		s1.addAll(Arrays.asList(new Integer[]{1,2,3,4,5,6}));
		Set<Integer>union=new HashSet<Integer>();
		union.addAll(s1);
		System.out.println("UNION-->"+union);
		Set<Integer>intersection=new HashSet<Integer>();
		intersection.retainAll(intersection);
		Set<Integer>difference=new HashSet<Integer>();
		difference.removeAll(s1);
		System.out.println("DIFFERRENCE-->"+difference);
		
	}

}
