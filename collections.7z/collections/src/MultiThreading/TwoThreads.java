package MultiThreading;

public class TwoThreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1=new Person();
		//Person p0=new Person();
		Sender s=new Sender();
		UserID1 t=new UserID1(p1,s);
		UserID2 t1=new UserID2(p1);
		t.start();
		t1.start();
	}

}
class Sender
{
	public void send(String msg)
	{
		System.out.println("Sedning msg");
		
		try
		{
			Thread.sleep(500);
		}
		catch(Exception e)
		{
			System.out.println("Thread interuptted");
		}
		System.out.println("Sent--->"+msg);
		
	} 
		
}
class Person
{
	public int id;
}
class UserID1 extends Thread
{
	Person p=null;
	String msg="pullamma";
	Sender sender=null;
	public UserID1(Person p2,Sender s) {
		// TODO Auto-generated constructor stub
		this.p=p2;
		this.sender=s;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized(sender)
		{
			for(int i=0;i<=50;i++)
			{
				if(i==50)
				{
					this.p.id=50;
					System.out.println("ID---->"+(this.p.id));
					sender.send(msg);
				}
			}
		}
	}
	
}
class UserID2 extends Thread
{
	Person p=null;
	
	public UserID2(Person p1) {
		this.p=p1;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<=150;i++)
		{
			if(i==100)
			{
				this.p.id=150;
				System.out.println("ID---->"+(this.p.id));
			}
		}
	}
	
}