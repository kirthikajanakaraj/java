package MultiThreading;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class MultiThreadEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t=new Thread(new Dora());
		Thread t1=new Thread(new Buji());
		t.start();
		t1.start();


	}

}
class Dora implements Runnable
{

	public void run() {
		
		try {
			File excel = new File("E:/kirthika/power.xls");
			FileInputStream fis = new FileInputStream(excel);
			HSSFWorkbook book = new HSSFWorkbook(fis);

			for (int i = 0; i < book.getNumberOfSheets(); i++) {
			HSSFSheet sheet = book.getSheetAt(i);

			Iterator<Row> itr = sheet.iterator();
			while (itr.hasNext()) {
			Row row = itr.next();

			Iterator<Cell> cellIterator = row.cellIterator();
			while (cellIterator.hasNext()) {

			Cell cell = cellIterator.next();

			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
			System.out.print(cell.getStringCellValue() + "\t");
			break;
			case Cell.CELL_TYPE_NUMERIC:
			System.out.print(cell.getNumericCellValue() + "\t");
			break;
			case Cell.CELL_TYPE_BOOLEAN:
			System.out.print(cell.getBooleanCellValue() + "\t");
			break;
			default:

			}
			}
			System.out.println("");
			}
			}
			} catch (IOException e) {
			}

	}
}
class Buji implements Runnable
{

	public void run() {
		
		try {
			File excel = new File("E:/kirthika/pandi.xls");
			FileInputStream fis = new FileInputStream(excel);
			HSSFWorkbook book = new HSSFWorkbook(fis);

			for (int i = 0; i < book.getNumberOfSheets(); i++) {
			HSSFSheet sheet = book.getSheetAt(i);

			Iterator<Row> itr = sheet.iterator();
			while (itr.hasNext()) {
			Row row = itr.next();

			Iterator<Cell> cellIterator = row.cellIterator();
			while (cellIterator.hasNext()) {

			Cell cell = cellIterator.next();

			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
			System.out.print(cell.getStringCellValue() + "\t");
			break;
			case Cell.CELL_TYPE_NUMERIC:
			System.out.print(cell.getNumericCellValue() + "\t");
			break;
			case Cell.CELL_TYPE_BOOLEAN:
			System.out.print(cell.getBooleanCellValue() + "\t");
			break;
			default:

			}
			}
			System.out.println("");
			}
			}
			} catch (IOException e) {
			}

	}
}
