package MultiThreading;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

//import Threads.Sum;

public class ManyThreads {

	public static void main(String[] args) {
		
		Test3 t=new Test3();
		t.run();
		ExecutorService es = Executors.newFixedThreadPool(10);
		 Future f1 = es.submit(new Sum(t.
				 
				 ));
		 Future f2 = es.submit(new Sum(t.));
		
		

	}

}
class Test3 implements Runnable
{

	public void run() {
		//List<Integer> li = new ArrayList<Integer>();
		try {
		FileReader fr = new FileReader("E:/kirthika/popey.txt");
		int l,k=0;
		List<Integer> value = new ArrayList<Integer>();
		while ((l=fr.read()) != -1) {
		//System.out.print((char) i);
		value.add(l);
		k++;
		}
		for (int j = 0; j <k; j++) {
		System.out.print((char)(int) (value.get(j)));
		}
		fr.close();
		} catch (IOException e) {
		e.printStackTrace();
		}
		}

	
}
class Sum implements Callable<Integer>
{
	List<Integer> arr;
	int StartIndex,EndIndex;
	Sum(List<Integer>Total,int StartIndex,int EndIndex)
	{
		this.arr=Total;
		this.StartIndex=StartIndex;
		this.EndIndex=EndIndex;
	}
	@Override
	public Integer call() throws Exception {
		// TODO Auto-generated method stub
		Integer Add=0;
		for(int i=StartIndex;i<EndIndex;i++)
		{
			Add=Add+arr.get(i);
		}
		return Add;
		
	}
}