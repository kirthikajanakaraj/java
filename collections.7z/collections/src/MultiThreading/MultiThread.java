package MultiThreading;

import java.io.FileReader;
import java.io.IOException;

public class MultiThread {

	public static void main(String[] args) {
		Thread t=new Thread(new Test());
		Thread t1=new Thread(new Test1());
		t.start();
		t1.start();

	}

}
class Test implements Runnable
{

	public void run() {
		 try
		 {
			 FileReader fr = new FileReader("E:/kirthika/popey.txt");
			 int i;
			 while ((i = fr.read()) != -1)
			 System.out.print((char) i);
			 } 
		 	catch (IOException e) 
		 		{
			 e.printStackTrace();
		 		}
	}
	
}
class Test1 implements Runnable
{

	public void run() {
		 try
		 {
			 FileReader fr = new FileReader("E:/kirthika/Tom.txt");
			 int i;
			 while ((i = fr.read()) != -1)
			 System.out.print((char) i);
			 } 
		 	catch (IOException e) 
		 		{
			 e.printStackTrace();
		 		}
	}
	
}