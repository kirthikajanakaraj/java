package Threads;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class Connectionjdbc {
	private Connectionjdbc()
	{
		
	}
	
	
	List<Connection>pool=new ArrayList<>();
	int poolsize=10;
	void initpool()
	{
		for(int i=0;i<poolsize;i++)
		{
			Connection con=getConnection();
		pool.add(con);
		}
	}
	Connection givenconnection()
	{
		Connection c=pool.get(1);
		pool.remove(1);
		return c;
	}
	void releseConnection(Connection con)
	{
		pool.add(con);
	}

}