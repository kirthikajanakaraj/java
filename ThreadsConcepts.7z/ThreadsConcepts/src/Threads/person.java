package Threads;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.xml.validation.Schema;

public class person {
	public static void main(String args[]) {

		try {
			Class.forName("org.postgresql.Driver");
			Connection con = EmployDB1.dbconnection();
			// Connection con =
			// DriverManager.getConnection("jdbc:postgresql://localhost:5432/mydb",
			// "postgres", "1234");
			// here sonoo is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select person.pid,person.firstname,person.lastname,person.mail,orders.oid,orders,oname from employeedb.person,employeedb.orders where employeedb.person.pid=1 and employeedb.orders.oid=100");
			//"select firstname,lastname,phone,age,ename,eid from employeedb.person p left join employeedb.eatables e on p.pid=e.pid");
			while (rs.next())
				System.out.println(rs.getString(1) + "   " + rs.getString(2) + "   " + rs.getString(3) + " "
						+ rs.getString(4) + " " + rs.getString(5) + "" + rs.getString(6));
			// System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " +
			// rs.getString(3));
			con.close();
			System.out.println();
			System.out.println("CONNECTION CLOSED");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
