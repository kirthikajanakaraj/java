package Threads;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Employmap {
	public static void main(String args[]) throws SQLException {
		try {
			StudentDB st = null;
			List<HashMap<String, String>> studentList = new ArrayList<>();
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/mydb", "postgres", "1234");
			// here sonoo is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from employeedb.employee");
			while (rs.next()) {
				String id = Integer.toString(rs.getInt(1));
				String name = rs.getString(2);
				String phone =Integer.toString(rs.getInt(3));
				String email = rs.getString(4);
				// st=new StudentDB(id,phone,name,email);
				// li.add(st);
				HashMap<String, String> mp = new HashMap<>();
				mp.put("id", id);
				mp.put("name", name);
				mp.put("phone", phone);
				mp.put("email", email);
				studentList.add(mp);
			}
			con.close();
			stmt.close();

			for (HashMap<String, String> h : studentList) {
				for (Map.Entry<String, String> k : h.entrySet()) {
					System.out.println(k.getKey() + "--------->" + k.getValue());
				}

			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
