package Threads;

import java.io.*;
public class CopyFiles {

	public static void main(String[] args) throws IOException {
		String source = "E:\\kirthika\\Tom.txt";  
		String dest = "E:\\kirthika\\jerry.txt";
		//File f = new File(source);
		
		FileInputStream fin = new FileInputStream(source);
		BufferedReader in = new BufferedReader(new InputStreamReader(fin));
		
		FileWriter fw = new FileWriter(dest,true);
		BufferedWriter out = new BufferedWriter(fw);
		
		String line = null;
		while( (line=in.readLine()) != null) {
			out.write(line);
			out.newLine();
			
		}
		in.close();
		out.close();
		

	}

}
