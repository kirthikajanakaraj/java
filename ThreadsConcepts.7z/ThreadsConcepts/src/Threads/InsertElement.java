package Threads;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class InsertElement {
	public static void main(String args[]) throws SQLException, ClassNotFoundException{
	Class.forName("org.postgresql.Driver");
	Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Employee","postgres","1234");
	PreparedStatement pstmt = conn.prepareStatement("insert into Employee1 values(?,?,?)"); 
	pstmt.setInt(1, 4);
	pstmt.setString(2, "rana");
	pstmt.setString(3, "xyzghgf");
	pstmt.executeUpdate();
	}


	

}
