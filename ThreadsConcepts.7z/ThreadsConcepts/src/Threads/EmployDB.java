package Threads;

import java.sql.*;
import java.util.Scanner;

public class EmployDB {
	
	public static void main(String args[]) throws SQLException, ClassNotFoundException {
		try {
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/mydb", "postgres", "1234");
		/*
		 * try { Class.forName("org.postgresql.Driver"); Connection con =
		 * DriverManager.getConnection(
		 * "jdbc:postgresql://localhost:5432/Employee", "postgres", "1234"); //
		 * here sonoo is database name, root is username and password Statement
		 * stmt = con.createStatement(); ResultSet rs =
		 * stmt.executeQuery("select * from Employee1"); while (rs.next())
		 * System.out.println(rs.getInt(1) + "   " + rs.getString(2) + "   " +
		 * rs.getString(3)); con.close(); } catch (Exception e) {
		 * System.out.println(e); }
		 */
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("1.insert \n 2.update \n 3.delete \n 4.display\n 5.exit");
			System.out.println("Enter your choice:");
			int n = sc.nextInt();

			switch (n) {
			case 1:

				System.out.println("please enter id");
				int id = sc.nextInt();
				System.out.println("please enter name");
				String  name = sc.next();
				System.out.println("please enter phone");
				int phone = sc.nextInt();
				System.out.println("please enter mail");
				String email = sc.next();
				addemployee(id, name, phone, email, con);
				break;
			case 2:
				System.out.println("please enter id");
				int id1 = sc.nextInt();
				System.out.println("please enter name");
				String name1 = sc.next();
				updateemployee(id1, name1, con);
				break;
			case 3:
				System.out.println("please enter id");
				int id2 = sc.nextInt();
				deleteemployee(id2, con);
				break;
			case 4:
				displayall(con);
				break;
			case 5:
				System.exit(0);
				//System.out.println("Invalid Input");
			}
		   }
			}
		
		
		catch(Exception e) {
System.out.println("u idiot give correct input");

}
	}

	public static void addemployee(int id, String name, int phone, String mail, Connection con) throws SQLException {

		PreparedStatement pstmt = con.prepareStatement("insert into employeedb.employee values(?,?,?,?)");
		pstmt.setInt(1, id);
		pstmt.setString(2, name);
		pstmt.setInt(3, phone);
		pstmt.setString(4, mail);
		pstmt.executeUpdate();
	}

	public static void updateemployee(int id, String name, Connection con) throws SQLException {
		PreparedStatement pstmt = con.prepareStatement("update employeedb.employee set empname = ? where empid= ?");
		pstmt.setString(1, name);
		pstmt.setInt(2, id);
		pstmt.executeUpdate();
	}

	public static void deleteemployee(int id, Connection con) throws SQLException {
		PreparedStatement pstmt = con.prepareStatement("delete from employeedb.employee where empid=?");
		pstmt.setInt(1, id);
		pstmt.executeUpdate();
	}

	public static void displayall(Connection con)

	{
		try {

			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from employeedb.employee");
			while (rs.next())
				System.out.println(rs.getInt(1) + "   " + rs.getString(2) + "   " + rs.getString(3));
			//con.close();
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}

	}
}
