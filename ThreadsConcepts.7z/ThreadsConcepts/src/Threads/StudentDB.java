package Threads;

public class StudentDB {
	private int id,phone;
	private String name,email;
	public StudentDB(int id, int phone, String name, String email) {
		this.id = id;
		this.phone = phone;
		this.name = name;
		this.email = email;
	}
	public int getId() {
		return id;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "{{"+this.getId()+" ,"
				+this.getPhone()+","+this.getName()+","+this.getEmail()+"}}";
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
