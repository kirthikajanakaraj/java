package Threads;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.concurrent.Callable;

public class dbtaskpool implements Callable
{

	@Override
	public Connection call() throws Exception {
		// TODO Auto-generated method stub
		Connection con=Connectionjdbc.getInstance().getConnection();
		Class.forName("org.postgresql.Driver");
		
		Statement stmt = con.createStatement();
		return ;
	}
	
}
