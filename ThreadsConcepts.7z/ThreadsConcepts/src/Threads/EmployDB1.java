package Threads;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class EmployDB1 {
	public static void main(String args[]) throws SQLException, IOException, ClassNotFoundException {

		Connection con = dbconnection();

		try {
			StudentDB st = null;
			List<StudentDB> li = new ArrayList<>();

			// Connection con =
			// DriverManager.getConnection("jdbc:postgresql://localhost:5432/mydb",
			// "postgres", "1234");

			// here sonoo is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from employeedb.employee");
			ResultSetMetaData rsmd = rs.getMetaData();
			DatabaseMetaData dbmd = con.getMetaData();
			System.out.println("Total Columns:" + rsmd.getColumnCount());
			System.out.println("Column Name of 1st column:" + rsmd.getColumnName(1));
			System.out.println("Column Type Name of 1st column:" + rsmd.getColumnTypeName(1));
			System.out.println(rsmd.getColumnLabel(1));
			System.out.println(rsmd.getColumnDisplaySize(1));
			System.out.println(rsmd.getScale(1));
			System.out.println(rsmd.getColumnType(1));
			System.out.println(rsmd.isCaseSensitive(1));
			// System.out.println(rsmd.isAutoIncrement(5));
			System.out.println(rsmd.getSchemaName(0));
			System.out.println(dbmd.getIdentifierQuoteString());
			System.out.println(dbmd.allProceduresAreCallable());
			System.out.println(dbmd.autoCommitFailureClosesAllResultSets());
			// System.out.println(dbmd.

			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int phone = rs.getInt(3);
				String email = rs.getString(4);
				st = new StudentDB(id, phone, name, email);
				li.add(st);

			}
			con.close();
			stmt.close();

			Iterator l = li.iterator();
			while (l.hasNext()) {
				StudentDB m = (StudentDB) l.next();
				System.out.println(m);
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		
		
		
		
		
		
		
		
		
		
	}

	public static Connection dbconnection()
			throws FileNotFoundException, IOException, ClassNotFoundException, SQLException {
		FileReader fr = new FileReader("propertypassword.properties");
		Properties p = new Properties();
		p.load(fr);
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/mydb", p.getProperty("username"),
				p.getProperty("password"));
		return con;
	}
}