package Threads;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Banking {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
				Numbers n=new Numbers();
				n.load();
				//Future f1=null;
			    ExecutorService es = Executors.newFixedThreadPool(10);
				/*int StartIndex=0,EndIndex=10000;
				List<Future<Integer>> lf = new ArrayList<Future<Integer>>();
			    for(int i=0;i<10;i++)
			    {
			    	lf.add(es.submit(new Sum(n.number,StartIndex,EndIndex)));
			    	 StartIndex=EndIndex;
					 EndIndex=EndIndex+10000;
			    }
			    Integer temp =0;
			    for (int i = 0; i < 10; i++)
			    {
			   Future<Integer> emm = lf.get(i);
				try
				{
					temp = temp + emm.get();
					
				} 
				catch (InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				catch (ExecutionException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    }
			    System.out.println("VALUES=====>>"+temp);
			   // ExecutorService.shutdown();
			   */
			    Future f1 = es.submit(new Sum(n.number,0,10000,n.share));
			    Future f2 = es.submit(new Sum(n.number,10000,20000,n.share));
			    Future f3 = es.submit(new Sum(n.number,20000,30000,n.share));
			    Future f4 = es.submit(new Sum(n.number,30000,40000,n.share));
			    Future f5 = es.submit(new Sum(n.number,40000,50000,n.share));
			    Future f6 = es.submit(new Sum(n.number,50000,60000,n.share));
			    Future f7 = es.submit(new Sum(n.number,60000,70000,n.share));
			    Future f8 = es.submit(new Sum(n.number,70000,80000,n.share));
			    Future f9 = es.submit(new Sum(n.number,80000,00000,n.share));
			    Future f10 = es.submit(new Sum(n.number,90000,100000,n.share));
			 
			    try {
					Integer s1=(Integer) f1.get();
					Integer s2=(Integer) f2.get();
					Integer s3=(Integer) f3.get();
					Integer s4=(Integer) f4.get();
					Integer s5=(Integer) f5.get();
					Integer s6=(Integer) f6.get();
					Integer s7=(Integer) f7.get();
					Integer s8=(Integer) f8.get();
					Integer s9=(Integer) f9.get();
					Integer s10=(Integer) f10.get();
					Integer Final=s1+s2+s3+s4+s5+s6+s7+s8+s9+s10;
					System.out.println("FINAL VALUE--->"+Final);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}   
		}

	}
	class Numbers
	{
		List<Integer> number = new ArrayList<>();
		List<Integer> share = new ArrayList<>();
		//Lock l= new ReentrantLock();
		Semaphore s = new Semaphore(3);
		public void load()
		{
			for(int i=0;i<100000;i++)
			{
				number.add(i);
				//l.lock();
				try {
					s.acquire();
					//synchronized (share) {
					share.add(i);
				//}
					s.release();
					//l.unlock();
				
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
				
		}
		
	}
	class Sum implements Callable<Integer>
	{
		List<Integer> arr,Shared;
		int StartIndex,EndIndex;
		Sum(List<Integer>Total,int StartIndex,int EndIndex,List<Integer>Tot)
		{
			this.arr=Total;
			this.StartIndex=StartIndex;
			this.EndIndex=EndIndex;
			this.Shared=Tot;
		}
		@Override
		public Integer call() throws Exception {
			// TODO Auto-generated method stub
			Integer Add=0;
			for(int i=StartIndex;i<EndIndex;i++)
			{
				Add=Add+arr.get(i);
				Shared.add(Add);
			
			}
			return Add;
			
		}
	}
	

