package Threads;

import java.util.Random;

public class Buffers 
{
	int x=0;
	boolean status=false;
	void set(int x)
	{
		this.x=x;
	}
	int get()
	{
		return this.x;
	}
}
public class Main1 {
	  public static void main(String[] args) {
	    Buffers buffer = new Buffers();
	    producer p = new producer(buffer);
	    consumer c = new consumer(buffer);

	    p.start();
	    c.start();
	  }
	}

class producer implements Runnable 
{
	Buffers b;
	Random r=new Random();
	public producer(Buffers b)
	{
		this.b=b;
	}
	
	public void run() 
	{
		for(int i=0;i<100;i++)
		{
			 while (true) {
			      int n = r.nextInt();
			      Buffers.producer();
			
		}
	}
}
class consumer implements Runnable
{	
	Buffers b;
	public consumer(Buffers b)
	{
		this.b=b;
	}
	public void run() 
	{
		 int n;
		    while (true) {
		      n = Buffers.consumer();
		    }
	this.b.get();
	notify();
	}
}
}
