# room-exp-app
This application is used to enter the room expendectures and tracking pupose.
it is developed in Java, AWT and JAXB.
