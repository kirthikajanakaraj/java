package com.pioneercoders.roomexp.common;

public interface IConfig {
	String FILE_PATH = "E:\\";
	String XML_FILE_NAME = FILE_PATH + "roommates.xml";

	String XL_FILE_NAME = FILE_PATH + "RoomExpen.xls";

}
