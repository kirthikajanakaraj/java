package com.pioneercoders.roomexp.ui;

public class Constants {
	
	
	public static final int ADD_ROOMMATE_PANEL=1;
	public static final int DELETE_ROOMMATE_PANEL=2;
	public static final int INSERT_EXPENDITURE_PANEL=3;
	public static final int SHOW_ALL_EXPENDITURES_PANEL=4;
	public static final Integer ADD_USER = null;
	
}
